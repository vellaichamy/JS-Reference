import { Component, OnInit, OnDestroy, Output, EventEmitter } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';

import { MqviewService } from '../core/ui/mqview.service';

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.scss']
})
export class HeaderComponent implements OnInit, OnDestroy {
  @Output() navToggled = new EventEmitter();
  navOpen = false;
  mqSub: Subscription;
  isLarge: boolean;
  // selected:any;

   menuItems = [{
        name: 'To-Do',
        icon: '',
        route: 'todo'
      },
      {
        name: 'About',
        icon: '',
        route: 'about'
      }];


  // menuItems: SideNav.getMenuItems;
  selected = this.menuItems[0];


  constructor(
    private router: Router,
    private mqview: MqviewService) { }

  ngOnInit() {
    this.router.events
      .filter(event => event instanceof NavigationStart && this.navOpen)
      .subscribe(event => this.toggleNav());

    this.mqSub = this.mqview.isLarge$.subscribe(
      isLarge => {
        this.isLarge = isLarge;

        if (this.isLarge && this.navOpen) {
          this.toggleNav();
        }
      }
    );
  }


   selectMenuItem(menuItem) {
      this.selected = menuItem;
      this.closeSideNav();
     // $state.go(menuItem.route);
    }

     closeSideNav() {
     // $mdSidenav('left').close();
    }


  toggleNav() {
    this.navOpen = !this.navOpen;
    this.navToggled.emit(this.navOpen);
  }

  ngOnDestroy() {
    this.mqSub.unsubscribe();
  }

}
