import { Injectable } from '@angular/core';

declare var alert: any;

@Injectable()
export class UtilsService {
  greeting = 'Hello';
  siteTitle = 'reStart-angular | ';

  alertGreeting(name: string) {
    alert(`${this.greeting}, ${name}!`);
  }

}
