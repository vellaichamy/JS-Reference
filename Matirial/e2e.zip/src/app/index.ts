export * from './core/app.component';
export * from './app.module';
