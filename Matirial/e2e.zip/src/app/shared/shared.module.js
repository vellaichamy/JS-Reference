angular.module('app.shared', [
  'shared.directives.backButton',
  'shared.services.Utils'
]);
