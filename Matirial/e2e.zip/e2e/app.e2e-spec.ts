import { RestartAngularPage } from './app.po';

describe('restart-angular App', function() {
  let page: RestartAngularPage;

  beforeEach(() => {
    page = new RestartAngularPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
