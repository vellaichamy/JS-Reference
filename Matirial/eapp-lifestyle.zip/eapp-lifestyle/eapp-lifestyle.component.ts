import { Customer } from './customer.interface';

import { Component, OnInit, NgModule, OnDestroy } from '@angular/core';
import { FormGroup, FormArray, FormBuilder,Validators,FormControl } from '@angular/forms';
import { AllComponentLableJson }  from  '../../../classes/all-component-lable-json';
import { CommonServiceForGetPostService} from '../../../services/common-service-for-get-post.service';
import { PersistVariableService } from '../../../services/persist-variable.service';
import { environment } from '../../../../environments/environment';
import { BrowserModule } from '@angular/platform-browser';
declare var $:any;

@Component({
  // moduleId: module.id,
 selector: 'eapp-lifestyle',
templateUrl: './eapp-lifestyle.component.html',
styleUrls: ['./eapp-lifestyle.component.css']

})


// export class EappLifestyleComponent implements OnInit {



export class EappLifestyleComponent implements OnInit {
  public lifeStyleForm: FormGroup;
  lifeStyleFormGroup: FormGroup;
  objectAllComponentLable:any;
  TypeOptions = ["label", "input", "email", "textarea", "checkbox", "select", "datepicker"];
  lifestyleLabelService    = environment.eappLifestyleLabelService;
  lifestyleGetDataService  = environment.eappLifestyleGetDataService;

  constructor( private _fb: FormBuilder, public _persistVariableService : PersistVariableService, private _commonServiceForGetPostService:CommonServiceForGetPostService) {
    this.objectAllComponentLable = new AllComponentLableJson();
  }


    ngOnInit() {
        this.lifeStyleForm = this._fb.group({
            //name: ['', [Validators.required, Validators.minLength(5)]],
            questions: this._fb.array([])
        });
        
        // add question
        this.addQuestion();
         /* subscribe to questions value changes */
        this.lifeStyleForm.controls['questions'].valueChanges.subscribe(x => {
          console.log(x);
        })


        if(!this._persistVariableService.getValueForJsonlableEappLifestyle()) {
            this.loadEappLifestyleLableJson();
            } else {
            this.objectAllComponentLable.arrayJsonEappLifestyle = this._persistVariableService.getValueForJsonlableEappLifestyle();
            }

        if(!this._persistVariableService.getValueForJsonDataEappLifestyle()) {
             //this.loadEappLifestyleDataJson();
           } else {
            this.objectAllComponentLable.arrayJsonDataEappLifestyle = this._persistVariableService.getValueForJsonDataEappLifestyle();
            }
    }

    loadEappLifestyleLableJson() {
            console.log('I m loading lifestyle epp quote lable');
            this._commonServiceForGetPostService.getJsonResponseByUrl( this.lifestyleLabelService ).subscribe(  arrayJsonEappLifestyle => {
            this.objectAllComponentLable.arrayJsonEappLifestyle = arrayJsonEappLifestyle;

            this._persistVariableService.setValueForJsonlableEappLifestyle(arrayJsonEappLifestyle);
            },
            error => this.objectAllComponentLable.errorMessage = <any>error    
            );
    }


    initQuestion() {
        return this._fb.group({
            street: ['', Validators.required],
            postcode: [''],
            zipcode:['']
        });
    }

    addQuestion() {
        const control = <FormArray>this.lifeStyleForm.controls['questions'];
        const addrCtrl = this.initQuestion();
        
        control.push(addrCtrl);
        
        /* subscribe to individual question value changes */
        addrCtrl.valueChanges.subscribe(x => {
          console.log('valueChanges',x);
        })
    }

    removeQuestion(i: number) {
        const control = <FormArray>this.lifeStyleForm.controls['questions'];
        control.removeAt(i);
    }

    save(model: Customer) {
        // call API to save
        // ...
        console.log(model);
    }
}








  

//   }

//   loadEappLifestyleDataJson(){
//     console.log('I m loading lifestyle data quote lable');
//     this._commonServiceForGetPostService.getJsonResponseByUrl( this.lifestyleGetDataService ).subscribe(  arrayJsonDataEappLifestyle => {
//     this.objectAllComponentLable.arrayJsonDataEappLifestyle = arrayJsonDataEappLifestyle;

//      this._persistVariableService.setValueForJsonDataEappLifestyle(arrayJsonDataEappLifestyle);
//     },
//       error => this.objectAllComponentLable.errorMessage = <any>error    
//     );
//   }



// }
