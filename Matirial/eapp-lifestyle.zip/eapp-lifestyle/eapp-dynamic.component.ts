import { Component, Input, OnInit,  OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder,Validators,FormControl } from '@angular/forms';
import { AllComponentLableJson }  from  '../../../classes/all-component-lable-json';
import { CommonServiceForGetPostService} from '../../../services/common-service-for-get-post.service';
import { PersistVariableService } from '../../../services/persist-variable.service';
import { environment } from '../../../../environments/environment';
import { BrowserModule } from '@angular/platform-browser';
// import { MyDatePickerModule, IMyOptions } from 'mydatepicker';

declare var $:any;


@Component({
    selector: 'dynamic',
    templateUrl: 'eapp-dynamic.component.html',
})
export class EappDynamicComponent  implements OnInit {

    @Input('group')
    public dynamicForm: FormGroup;

    //Global Variables
    objectAllComponentLable:any;
    TypeOptions = ["label", "input", "email", "textarea", "checkbox", "select", "datepicker"];
    lifestyleLabelService    = environment.eappLifestyleLabelService;
	lifestyleGetDataService  = environment.eappLifestyleGetDataService;

	constructor( public _persistVariableService : PersistVariableService, private _commonServiceForGetPostService:CommonServiceForGetPostService) {
  		this.objectAllComponentLable = new AllComponentLableJson();
    
  }

  ngOnInit() {
  	   	this.loadEappLifestyleLableJson();
  	 	// this.loadEappLifestyleDataJson();
  }

  loadEappLifestyleLableJson() {
    console.log('I m loading lifestyle epp quote lable');
 	  	this._commonServiceForGetPostService.getJsonResponseByUrl( this.lifestyleLabelService ).subscribe(  arrayJsonEappLifestyle => {
  		// this.objectAllComponentLable.arrayJsonEappLifestyle = arrayJsonEappLifestyle;
     	this._persistVariableService.setValueForJsonlableEappLifestyle(arrayJsonEappLifestyle);
   		},
    	error => this.objectAllComponentLable.errorMessage = <any>error    
    );
  }

  loadEappLifestyleDataJson(){
    console.log('I m loading lifestyle data quote lable');
   		this._commonServiceForGetPostService.getJsonResponseByUrl( this.lifestyleGetDataService ).subscribe(  arrayJsonDataEappLifestyle => {
  		this.objectAllComponentLable.arrayJsonDataEappLifestyle = arrayJsonDataEappLifestyle;
   		this._persistVariableService.setValueForJsonDataEappLifestyle(arrayJsonDataEappLifestyle);
    	},
     	error => this.objectAllComponentLable.errorMessage = <any>error    
    );
  }



}