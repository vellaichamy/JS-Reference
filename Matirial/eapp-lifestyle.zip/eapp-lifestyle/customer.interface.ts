export interface Customer {
    name: string;
    questions: Question[];
}

// export interface Question {
//     street: string;
//     postcode: string;
//      str1: string;
//       str2: string;
//        str3: string;
// }